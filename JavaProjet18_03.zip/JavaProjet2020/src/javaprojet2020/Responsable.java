/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojet2020;

import java.util.ArrayList;

/**
 *
 * @author julie
 */
public class Responsable extends Employe {

    private ArrayList<Employe> lesSubs;

    public Responsable(String nom, String prenom, int matricule, int indiceSalaire) {
        super(nom, prenom, matricule, indiceSalaire);
        lesSubs = new ArrayList<>();
    }

    public void ajSub(Employe empl) {
        lesSubs.add(empl);
    }

    public double calculSalaire() {
        return this.getIndiceSalaire() * 12;
    }

    public double calculSalaireBranche() {
        return this.calculSalaireBrancheEtape(0);
    }

    public double calculSalaireBrancheEtape(double sal) {
        double salaire = sal + this.calculSalaire();
        for (Employe empl : this.lesSubs) {
            if (empl instanceof Responsable) {
                salaire = ((Responsable) empl).calculSalaireBrancheEtape(salaire);
            } else {
                salaire = salaire + empl.calculSalaire();
            }
        }
        return salaire;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    public void affHie() {
        System.out.println("Responsable " + this);
        for (Employe empl : this.lesSubs) {
            String etoile = " ";
            if (empl instanceof Responsable) {
                etoile = "*";
            }
            System.out.println("\t" + empl + " " + etoile);
        }
        for (Employe empl : this.lesSubs) {
            if (empl instanceof Responsable) {
                ((Responsable) empl).affHie();
            }
        }
    }

    public void affHieDir() {
        System.out.println("Responsable " + this);
        for (Employe empl : this.lesSubs) {
            String etoile = " ";
            if (empl instanceof Responsable) {
                etoile = "*";
            }
            System.out.println("\t " + empl + " " + etoile);
        }
    }

}
