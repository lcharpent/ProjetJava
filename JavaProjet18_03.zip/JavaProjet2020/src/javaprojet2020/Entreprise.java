/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojet2020;

import java.io.*;
import java.util.*;

/**
 *
 * @author julie
 */
public class Entreprise {

    private TreeSet<Employe> lesEmployes;

    public Entreprise(TreeSet<Employe> lesEmployes) {
        this.lesEmployes = lesEmployes;
    }

    public Entreprise() {
        lesEmployes = new TreeSet<>();

        /*Scanner sc;
        try {
            sc = new Scanner(new File("C:\\Users\\julie\\OneDrive\\Documents\\ISIS\\Corona\\EntrepriseJava.docx"));
            while (sc.hasNext()) {

                String ligne = sc.nextLine();
                StringTokenizer stoken = new StringTokenizer(ligne, " ");
                String classe = stoken.nextToken();
                String nom = stoken.nextToken();
                String prenom = stoken.nextToken();
                String rien1 = stoken.nextToken();
                String rien2 = stoken.nextToken();
                int matricule = Integer.valueOf(stoken.nextToken());
                String rien3 = stoken.nextToken();
                String rien4 = stoken.nextToken();
                String rien5 = stoken.nextToken();
                String rien6 = stoken.nextToken();
                String rien7 = stoken.nextToken();
                String rien8 = stoken.nextToken();
                int indiceSalaire = Integer.valueOf(stoken.nextToken());
                String etoile = stoken.nextToken();
                String rien9 = stoken.nextToken();
                int ventes = Integer.valueOf(stoken.nextToken());

                if (classe.equals("Responsable")) {
                    lesEmployes.add(new Responsable(nom, prenom, matricule, indiceSalaire));
                }
                if (classe.equals("\t") && etoile.equals(" ")) {
                    lesEmployes.add(new EmployeDeBase(nom, prenom, matricule, indiceSalaire));
                }
                if (classe.equals("Commercial")) {
                    lesEmployes.add(new Commercial(nom, prenom, matricule, indiceSalaire, ventes));
                }

            }
        } catch (FileNotFoundException e) {
            System.out.println(e);
        }*/
    }

    public void ajEmploye(Employe empl) {
        lesEmployes.add(empl);
    }

    public double calculSalairesEntreprise() {
        double salaire = 0;
        for (Employe empl : lesEmployes) {
            salaire = salaire + empl.calculSalaire();
        }
        return salaire;
    }

    @Override
    public String toString() {
        return "Entreprise : " + lesEmployes;
    }

    public void affEntreprise() {
        for (Employe empl : this.lesEmployes) {
            if (empl instanceof Responsable) {
                ((Responsable) empl).affHieDir();
                System.out.println();
            }
            if (empl instanceof Commercial) {
                System.out.println("Commercial " + empl);
            }
        }
    }

}
