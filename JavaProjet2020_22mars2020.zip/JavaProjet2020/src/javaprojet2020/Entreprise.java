/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojet2020;

import java.io.*;
import java.util.*;

/**
 *
 * @author julie
 */
public class Entreprise implements Serializable {

    private TreeSet<Employe> lesEmployes;

    public Entreprise(TreeSet<Employe> lesEmployes) {
        this.lesEmployes = lesEmployes;
    }

    public Entreprise() {
        lesEmployes = new TreeSet<>();

        /*Scanner sc;
        try {
            sc = new Scanner(new File("C:\\Users\\julie\\OneDrive\\Documents\\ISIS\\Corona\\EntrepriseJava.docx"));
            while (sc.hasNext()) {

                String ligne = sc.nextLine();
                StringTokenizer stoken = new StringTokenizer(ligne, " ");
                String classe = stoken.nextToken();
                String nom = stoken.nextToken();
                String prenom = stoken.nextToken();
                String rien1 = stoken.nextToken();
                String rien2 = stoken.nextToken();
                int matricule = Integer.valueOf(stoken.nextToken());
                String rien3 = stoken.nextToken();
                String rien4 = stoken.nextToken();
                String rien5 = stoken.nextToken();
                String rien6 = stoken.nextToken();
                String rien7 = stoken.nextToken();
                String rien8 = stoken.nextToken();
                int indiceSalaire = Integer.valueOf(stoken.nextToken());
                String etoile = stoken.nextToken();
                String rien9 = stoken.nextToken();
                int ventes = Integer.valueOf(stoken.nextToken());

                if (classe.equals("Responsable")) {
                    lesEmployes.add(new Responsable(nom, prenom, matricule, indiceSalaire));
                }
                if (classe.equals("\t") && etoile.equals(" ")) {
                    lesEmployes.add(new EmployeDeBase(nom, prenom, matricule, indiceSalaire));
                }
                if (classe.equals("Commercial")) {
                    lesEmployes.add(new Commercial(nom, prenom, matricule, indiceSalaire, ventes));
                }

            }
        } catch (FileNotFoundException e) {
            System.out.println(e);
        }*/
    }

    public void ajEmploye(Employe empl) {
        lesEmployes.add(empl);
    }

    public double calculSalairesEntreprise() {
        double salaire = 0;
        for (Employe empl : lesEmployes) {
            salaire = salaire + empl.calculSalaire();
        }
        return salaire;
    }

    @Override
    public String toString() {
        String entreprise = "";
        for (Employe empl : this.lesEmployes) {
            if (empl instanceof Responsable) {
                entreprise = entreprise + ((Responsable) empl).laHieDir() + "\n";
            }
            if (empl instanceof Commercial) {
                entreprise = entreprise + "Commercial " + empl + "\n";
            }
        }
        return entreprise;
    }

    /*
    Méthodes d'instance
     */
    /**
     * Méthode de sauvegarde de l'instance dans le fichier dont le chemin est
     * passé en paramètre.
     *
     * @param filePath Le chemin du fichier de sauvegarde
     * @throws java.io.FileNotFoundException
     */
    public void sauver(String filePath)
            throws FileNotFoundException, IOException {
        // Un flux binaire en écriture vers le fichier passé en paramètre
        FileOutputStream fos = new FileOutputStream(filePath);
        // Un flux de traitement des objets construit sur le flux binaire
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        // Ecriture de l'objet courant (this) dans le flux de traitement,
        // donc dans le fichier
        oos.writeObject(this);
        // Fermeture du flux (obligatoire)
        oos.close();
    }

    /**
     * Méthode de classe permettant de lire et retourner un objet Voiture dans
     * le fichier dont le chemin est passé en paramètre.
     *
     * @param filePath Le chemin du fichier lu
     * @return L'objet Personne lu dans le fichier, ou null s'il n'y en a pas.
     * @throws java.io.FileNotFoundException
     * @throws java.lang.ClassNotFoundException
     */
    public static Entreprise lire(String filePath)
            throws FileNotFoundException, IOException, ClassNotFoundException {
        // Un flux binaire en lecture sur le fichier passé en paramètre
        FileInputStream fis = new FileInputStream(filePath);
        // Un flux de traitement des objets construit sur le flux binaire
        ObjectInputStream ois = new ObjectInputStream(fis);
        // Lecture d'un objet dans le flux de traitement. La méthode readObject()
        // retourne un Object, il convient donc de le transtyper (cast) en Personne.
        Entreprise obj = (Entreprise) ois.readObject();
        ois.close();
        return obj;
    }

}
