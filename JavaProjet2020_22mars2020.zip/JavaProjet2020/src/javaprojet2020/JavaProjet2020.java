/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojet2020;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author julie
 */
public class JavaProjet2020 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//creation des employes
        Responsable a = new Responsable("A", "Agnes", 15600, 1);
        Employe b = new EmployeDeBase("B", "Borian", 15601, 10);
        Responsable c = new Responsable("C", "Corie", 15602, 100);
        Responsable d = new Responsable("D", "Dora", 15603, 1);
        Responsable e = new Responsable("E", "Eleonore", 15604, 10);
        Employe f = new EmployeDeBase("F", "Felix", 15605, 100);
        Responsable g = new Responsable("G", "Guillaume", 15606, 1);
        Responsable h = new Responsable("H", "Harry", 15607, 10);
        Employe i = new EmployeDeBase("I", "Ines", 15608, 100);
        Responsable j = new Responsable("J", "Julie", 15609, 1);
        Employe k = new EmployeDeBase("K", "Kriss", 15610, 10);
        Employe l = new EmployeDeBase("L", "Lola", 15611, 100);
        Employe m = new EmployeDeBase("M", "Manon", 15612, 1);
        Employe n = new EmployeDeBase("N", "Noe", 15613, 10);
        Employe o = new Commercial("O", "Olivier", 15614, 100, 1000);
        Employe p = new Commercial("P", "Patrick", 15615, 1, 10);

//ajout des subs
        a.ajSub(b);
        a.ajSub(c);
        a.ajSub(d);
        c.ajSub(e);
        c.ajSub(f);
        d.ajSub(g);
        e.ajSub(h);
        e.ajSub(i);
        e.ajSub(j);
        g.ajSub(k);
        h.ajSub(l);
        h.ajSub(m);
        j.ajSub(n);

//creation entreprise
        Entreprise foxnot = new Entreprise();

//ajout des employes a l'entrepise
        foxnot.ajEmploye(a);
        foxnot.ajEmploye(b);
        foxnot.ajEmploye(c);
        foxnot.ajEmploye(d);
        foxnot.ajEmploye(e);
        foxnot.ajEmploye(f);
        foxnot.ajEmploye(g);
        foxnot.ajEmploye(h);
        foxnot.ajEmploye(i);
        foxnot.ajEmploye(j);
        foxnot.ajEmploye(k);
        foxnot.ajEmploye(l);
        foxnot.ajEmploye(m);
        foxnot.ajEmploye(n);
        foxnot.ajEmploye(o);
        foxnot.ajEmploye(p);


        String filepath = "organigramEntrepris.dat";
        try {
            foxnot.sauver(filepath);
            System.out.println("Entreprise sauvegardée dans le fichier : " + filepath);
        } catch (IOException ex) {
            Logger.getLogger(JavaProjet2020.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            Entreprise lue = Entreprise.lire(filepath);
            System.out.println("Entreprise lue =\n" + lue);
        } catch (IOException ex) {
            Logger.getLogger(JavaProjet2020.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JavaProjet2020.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
